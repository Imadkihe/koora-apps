import 'package:flutter/material.dart';

void main() {
  runApp(const KooraExternalPlayerApp());
}

class KooraExternalPlayerApp extends StatelessWidget {
  const KooraExternalPlayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مشغل كورة لايف الخارجي - Koora Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF090D16),
      ),
      home: const ExternalPlayerScreen(
        initialStreamUrl: 'https://11.kooora4sport.fun/2026/09/bein-sport-1.html',
        initialTitle: 'إيطاليا vs فرنسا',
        initialChannel: 'beIN Sports 1 HD',
      ),
    );
  }
}

class ExternalPlayerScreen extends StatefulWidget {
  final String initialStreamUrl;
  final String initialTitle;
  final String initialChannel;

  const ExternalPlayerScreen({
    super.key,
    required this.initialStreamUrl,
    required this.initialTitle,
    required this.initialChannel,
  });

  @override
  State<ExternalPlayerScreen> createState() => _ExternalPlayerScreenState();
}

class _ExternalPlayerScreenState extends State<ExternalPlayerScreen> {
  late String currentUrl;
  late String currentTitle;
  late String selectedQuality;
  bool isLocked = false;
  bool isPlaying = true;

  @override
  void initState() {
    super.initState();
    currentUrl = widget.initialStreamUrl;
    currentTitle = widget.initialTitle;
    selectedQuality = '1080p FHD';
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: isLocked
            ? null
            : AppBar(
                backgroundColor: const Color(0xFF111827),
                title: Text('مشغل كورة لايف الخارجي: $currentTitle'),
                actions: [
                  IconButton(
                    icon: Icon(isLocked ? Icons.lock : Icons.lock_open),
                    onPressed: () => setState(() => isLocked = !isLocked),
                    tooltip: 'قفل الشاشة أثناء المشاهدة',
                  ),
                ],
              ),
        body: Column(
          children: [
            // منطقة تشغيل الفيديو الخالية تماماً من الإعلانات
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Container(
                color: Colors.black,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          isPlaying ? Icons.live_tv : Icons.pause_circle_filled,
                          color: const Color(0xFF10B981),
                          size: 64,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          currentTitle,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'الجودة: $selectedQuality | بدون إعلانات (Ad-Free Stream)',
                          style: const TextStyle(fontSize: 13, color: Colors.greenAccent),
                        ),
                      ],
                    ),
                    Positioned(
                      bottom: 10,
                      left: 12,
                      right: 12,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                            icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.white),
                            onPressed: isLocked ? null : () => setState(() => isPlaying = !isPlaying),
                          ),
                          Text(currentUrl, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                          IconButton(
                            icon: const Icon(Icons.lock_outline, color: Colors.white),
                            onPressed: () => setState(() => isLocked = !isLocked),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // اختيار الجودة والسيرفرات
            Padding(
              padding: const EdgeInsets.all(16),
              child: Wrap(
                spacing: 8,
                children: ['1080p FHD', '720p HD', '480p SD', '360p Low'].map((q) {
                  return ChoiceChip(
                    label: Text(q),
                    selected: selectedQuality == q,
                    onSelected: isLocked ? null : (_) => setState(() => selectedQuality = q),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
