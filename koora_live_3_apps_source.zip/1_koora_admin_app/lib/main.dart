import 'package:flutter/material.dart';
import 'dart:convert';

void main() {
  runApp(const KooraAdminApp());
}

final List<Map<String, dynamic>> initialMatches = [
  {
    "id": "m1",
    "team1": "نابالكارنيرو",
    "logo1": "https://kooralive.asia/wp-content/uploads/2026/10/alba_img_6ae105f67c7c7.png",
    "team2": "ريال بيتيس",
    "logo2": "https://kooralive.asia/wp-content/uploads/2026/11/alba_img_6aefa077757eb.png",
    "time": "21:00",
    "score1": 2,
    "score2": 3,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "كأس ملك إسبانيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/shahid2.html",
    "channel": "Shahid VIP 2"
  },
  {
    "id": "m2",
    "team1": "تارانكون",
    "logo1": "https://kooralive.asia/wp-content/uploads/2026/10/alba_img_6ae1064055928.png",
    "team2": "ليفانتي",
    "logo2": "https://kooralive.asia/wp-content/uploads/2026/11/alba_img_6aefa07908fad.png",
    "time": "21:00",
    "score1": 1,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "كأس ملك إسبانيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/shahid3.html",
    "channel": "Shahid VIP 3"
  },
  {
    "id": "m3",
    "team1": "ساحل العاج",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad0c5f90.png",
    "team2": "غامبيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad0d3cff.png",
    "time": "22:00",
    "score1": 2,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-5.html",
    "channel": "beIN Sports 5"
  },
  {
    "id": "m4",
    "team1": "السنغال",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab719051.png",
    "team2": "السودان",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab729d9b.png",
    "time": "22:00",
    "score1": 2,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-2.html",
    "channel": "beIN Sports 2"
  },
  {
    "id": "m5",
    "team1": "الكاميرون",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab62ec8d.png",
    "team2": "ناميبيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab63813a.png",
    "time": "22:00",
    "score1": 2,
    "score2": 0,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-6.html",
    "channel": "beIN Sports 6"
  },
  {
    "id": "m6",
    "team1": "بنين",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab4e0c41.png",
    "team2": "إفريقيا الوسطى",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab51dacc.png",
    "time": "22:00",
    "score1": 4,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-8.html",
    "channel": "beIN Sports 8"
  },
  {
    "id": "m7",
    "team1": "إنجلترا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae172439.png",
    "team2": "كرواتيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae17c0eb.png",
    "time": "22:45",
    "score1": 1,
    "score2": 0,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-3.html",
    "channel": "beIN Sports 3"
  },
  {
    "id": "m8",
    "team1": "إيطاليا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adecc082.png",
    "team2": "فرنسا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aded67a0.png",
    "time": "22:45",
    "score1": 1,
    "score2": 1,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-1.html",
    "channel": "beIN Sports 1"
  },
  {
    "id": "m9",
    "team1": "ألبانيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae446581.png",
    "team2": "فنلندا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae472837.png",
    "time": "22:45",
    "score1": 1,
    "score2": 0,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/10/bein-xtra-1.html",
    "channel": "beIN Xtra 1"
  },
  {
    "id": "m10",
    "team1": "التشيك",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adfc2b8a.png",
    "team2": "إسبانيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adfcbb47.png",
    "time": "22:45",
    "score1": 0,
    "score2": 0,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-4.html",
    "channel": "beIN Sports 4"
  },
  {
    "id": "m11",
    "team1": "غانا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aa823f7d.png",
    "team2": "الصومال",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aa82e3ac.png",
    "time": "18:00",
    "score1": 2,
    "score2": 0,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-1.html",
    "channel": "beIN Sports 1"
  },
  {
    "id": "m12",
    "team1": "الكونغو",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52a989d9b9.png",
    "team2": "سيراليون",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52a98a7b11.png",
    "time": "19:00",
    "score1": 3,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-3.html",
    "channel": "beIN Sports 3"
  },
  {
    "id": "m13",
    "team1": "غينيا الاستوائية",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aae2b4c7.png",
    "team2": "زيمبابوي",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aae4d91a.png",
    "time": "19:00",
    "score1": 0,
    "score2": 0,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-5.html",
    "channel": "beIN Sports 5"
  },
  {
    "id": "m14",
    "team1": "مدغشقر",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aad016a3.png",
    "team2": "غينيا بيساو",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aad206e8.png",
    "time": "19:00",
    "score1": 1,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-8.html",
    "channel": "beIN Sports 8"
  },
  {
    "id": "m15",
    "team1": "أرمينيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52addd3216.png",
    "team2": "قبرص",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adddc52a.png",
    "time": "20:00",
    "score1": 1,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-4.html",
    "channel": "beIN Sports 4"
  },
  {
    "id": "m16",
    "team1": "تركيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad9cca89.png",
    "team2": "بلجيكا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad9d5ee8.png",
    "time": "20:00",
    "score1": 1,
    "score2": 2,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-1.html",
    "channel": "beIN Sports 1"
  },
  {
    "id": "m17",
    "team1": "غينيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52acf339ef.png",
    "team2": "إرتريا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52acf42155.png",
    "time": "20:00",
    "score1": 2,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-7.html",
    "channel": "beIN Sports 7"
  }
];

class KooraAdminApp extends StatelessWidget {
  const KooraAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'كورة لايف - لوحة تحكم الأدمن',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121A23),
        primaryColor: const Color(0xFF10B981),
        cardColor: const Color(0xFF1C2733),
      ),
      home: const AdminDashboardScreen(),
    );
  }
}

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  late List<Map<String, dynamic>> matches;
  bool stealthAdBlockEnabled = true;
  bool blockBannerAds = true;
  bool blockPopupsAndRedirects = true;
  bool stripObfuscatedScripts = true;
  bool forceExternalPlayer = true;
  String externalPlayerScheme = "kooraplayer://play";
  String externalPlayerPackage = "com.kooralive.player";

  @override
  void initState() {
    super.initState();
    matches = List<Map<String, dynamic>>.from(initialMatches.map((m) => Map<String, dynamic>.from(m)));
  }

  void _updateScore(int index, int delta1, int delta2) {
    setState(() {
      matches[index]['score1'] = (matches[index]['score1'] as int) + delta1;
      if (matches[index]['score1'] < 0) matches[index]['score1'] = 0;
      matches[index]['score2'] = (matches[index]['score2'] as int) + delta2;
      if (matches[index]['score2'] < 0) matches[index]['score2'] = 0;
    });
  }

  void _cycleStatus(int index) {
    setState(() {
      final current = matches[index]['status'];
      if (current == 'live') {
        matches[index]['status'] = 'finished';
        matches[index]['statusText'] = 'انتهت';
      } else if (current == 'finished') {
        matches[index]['status'] = 'comming-soon';
        matches[index]['statusText'] = 'بعد قليل';
      } else {
        matches[index]['status'] = 'live';
        matches[index]['statusText'] = 'جارية الان';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: const Color(0xFF1C2733),
            title: const Text('لوحة تحكم الأدمن - كورة لايف'),
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.sports_soccer), text: 'إدارة المباريات'),
                Tab(icon: Icon(Icons.shield), text: 'مانع الإعلانات الخفي'),
                Tab(icon: Icon(Icons.play_circle_fill), text: 'ربط المشغل الخارجي'),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              // Tab 1: Matches Management
              ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: matches.length,
                itemBuilder: (context, idx) {
                  final m = matches[idx];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${m["team1"]} vs ${m["team2"]}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                              ActionChip(
                                label: Text(m['statusText']),
                                backgroundColor: m['status'] == 'live' ? Colors.red.shade800 : Colors.blueGrey,
                                onPressed: () => _cycleStatus(idx),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Row(
                                children: [
                                  IconButton(onPressed: () => _updateScore(idx, 1, 0), icon: const Icon(Icons.add_circle, color: Colors.greenAccent)),
                                  Text('${m["score1"]}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                  IconButton(onPressed: () => _updateScore(idx, -1, 0), icon: const Icon(Icons.remove_circle, color: Colors.redAccent)),
                                ],
                              ),
                              const Text('-', style: TextStyle(fontSize: 20)),
                              Row(
                                children: [
                                  IconButton(onPressed: () => _updateScore(idx, 0, 1), icon: const Icon(Icons.add_circle, color: Colors.greenAccent)),
                                  Text('${m["score2"]}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                  IconButton(onPressed: () => _updateScore(idx, 0, -1), icon: const Icon(Icons.remove_circle, color: Colors.redAccent)),
                                ],
                              ),
                            ],
                          ),
                          Text('البطولة: ${m["tournament"]} | القناة: ${m["channel"]}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                          Text('رابط البث: ${m["streamUrl"]}', style: const TextStyle(color: Colors.cyanAccent, fontSize: 12)),
                        ],
                      ),
                    ),
                  );
                },
              ),
              // Tab 2: Stealth Ad-Blocker Config
              ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  SwitchListTile(
                    title: const Text('تفعيل حجب الإعلانات الخفي (Stealth Ad-Blocker)'),
                    subtitle: const Text('يعمل في الخلفية بصمت تام لحذف الإعلانات من الكود المصدري وسيرفرات البث'),
                    value: stealthAdBlockEnabled,
                    onChanged: (v) => setState(() => stealthAdBlockEnabled = v),
                  ),
                  SwitchListTile(
                    title: const Text('حذف بنرات الإعلانات (.koora-match-ad & .albayalla-e3lan)'),
                    subtitle: const Text('إزالة إعلان كورة سكور وروابط Google Play / App Store تلقائياً'),
                    value: blockBannerAds,
                    onChanged: (v) => setState(() => blockBannerAds = v),
                  ),
                  SwitchListTile(
                    title: const Text('منع النوافذ المنبثقة والتحويلات الإجبارية (Pop-ups)'),
                    subtitle: const Text('منع فتح أي نوافذ إعلانية خارجية عند ضغط المستخدم على المباراة'),
                    value: blockPopupsAndRedirects,
                    onChanged: (v) => setState(() => blockPopupsAndRedirects = v),
                  ),
                  SwitchListTile(
                    title: const Text('تعطيل السكربتات المشفرة وحقن الإعلانات (Obfuscated Scripts)'),
                    subtitle: const Text('حظر سكربتات AlbaYalla_0x وتتبع Google Analytics'),
                    value: stripObfuscatedScripts,
                    onChanged: (v) => setState(() => stripObfuscatedScripts = v),
                  ),
                ],
              ),
              // Tab 3: External Player Link Config
              ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  SwitchListTile(
                    title: const Text('توجيه المشاهدة تلقائياً للمشغل الخارجي'),
                    subtitle: const Text('عند ضغط المستخدم على أي مباراة يتم فتح تطبيق المشغل الخارجي فوراً'),
                    value: forceExternalPlayer,
                    onChanged: (v) => setState(() => forceExternalPlayer = v),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'بروتوكول الربط (Custom Deep Link Scheme)',
                      border: OutlineInputBorder(),
                    ),
                    controller: TextEditingController(text: externalPlayerScheme),
                    onChanged: (v) => externalPlayerScheme = v,
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'معرف حزمة المشغل الخارجي (Package Name)',
                      border: OutlineInputBorder(),
                    ),
                    controller: TextEditingController(text: externalPlayerPackage),
                    onChanged: (v) => externalPlayerPackage = v,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
