import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'stealth_adblocker.dart';

void main() {
  runApp(const KooraUserApp());
}

final List<Map<String, dynamic>> initialMatches = [
  {
    "id": "m1",
    "team1": "نابالكارنيرو",
    "logo1": "https://kooralive.asia/wp-content/uploads/2026/10/alba_img_6ae105f67c7c7.png",
    "team2": "ريال بيتيس",
    "logo2": "https://kooralive.asia/wp-content/uploads/2026/11/alba_img_6aefa077757eb.png",
    "time": "21:00",
    "score1": 2,
    "score2": 3,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "كأس ملك إسبانيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/shahid2.html",
    "channel": "Shahid VIP 2"
  },
  {
    "id": "m2",
    "team1": "تارانكون",
    "logo1": "https://kooralive.asia/wp-content/uploads/2026/10/alba_img_6ae1064055928.png",
    "team2": "ليفانتي",
    "logo2": "https://kooralive.asia/wp-content/uploads/2026/11/alba_img_6aefa07908fad.png",
    "time": "21:00",
    "score1": 1,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "كأس ملك إسبانيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/shahid3.html",
    "channel": "Shahid VIP 3"
  },
  {
    "id": "m3",
    "team1": "ساحل العاج",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad0c5f90.png",
    "team2": "غامبيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad0d3cff.png",
    "time": "22:00",
    "score1": 2,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-5.html",
    "channel": "beIN Sports 5"
  },
  {
    "id": "m4",
    "team1": "السنغال",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab719051.png",
    "team2": "السودان",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab729d9b.png",
    "time": "22:00",
    "score1": 2,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-2.html",
    "channel": "beIN Sports 2"
  },
  {
    "id": "m5",
    "team1": "الكاميرون",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab62ec8d.png",
    "team2": "ناميبيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab63813a.png",
    "time": "22:00",
    "score1": 2,
    "score2": 0,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-6.html",
    "channel": "beIN Sports 6"
  },
  {
    "id": "m6",
    "team1": "بنين",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab4e0c41.png",
    "team2": "إفريقيا الوسطى",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ab51dacc.png",
    "time": "22:00",
    "score1": 4,
    "score2": 1,
    "status": "live",
    "statusText": "جارية الان",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-8.html",
    "channel": "beIN Sports 8"
  },
  {
    "id": "m7",
    "team1": "إنجلترا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae172439.png",
    "team2": "كرواتيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae17c0eb.png",
    "time": "22:45",
    "score1": 1,
    "score2": 0,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-3.html",
    "channel": "beIN Sports 3"
  },
  {
    "id": "m8",
    "team1": "إيطاليا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adecc082.png",
    "team2": "فرنسا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aded67a0.png",
    "time": "22:45",
    "score1": 1,
    "score2": 1,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-1.html",
    "channel": "beIN Sports 1"
  },
  {
    "id": "m9",
    "team1": "ألبانيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae446581.png",
    "team2": "فنلندا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ae472837.png",
    "time": "22:45",
    "score1": 1,
    "score2": 0,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/10/bein-xtra-1.html",
    "channel": "beIN Xtra 1"
  },
  {
    "id": "m10",
    "team1": "التشيك",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adfc2b8a.png",
    "team2": "إسبانيا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adfcbb47.png",
    "time": "22:45",
    "score1": 0,
    "score2": 0,
    "status": "comming-soon",
    "statusText": "بعد قليل",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-4.html",
    "channel": "beIN Sports 4"
  },
  {
    "id": "m11",
    "team1": "غانا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aa823f7d.png",
    "team2": "الصومال",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aa82e3ac.png",
    "time": "18:00",
    "score1": 2,
    "score2": 0,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-1.html",
    "channel": "beIN Sports 1"
  },
  {
    "id": "m12",
    "team1": "الكونغو",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52a989d9b9.png",
    "team2": "سيراليون",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52a98a7b11.png",
    "time": "19:00",
    "score1": 3,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-3.html",
    "channel": "beIN Sports 3"
  },
  {
    "id": "m13",
    "team1": "غينيا الاستوائية",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aae2b4c7.png",
    "team2": "زيمبابوي",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aae4d91a.png",
    "time": "19:00",
    "score1": 0,
    "score2": 0,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-5.html",
    "channel": "beIN Sports 5"
  },
  {
    "id": "m14",
    "team1": "مدغشقر",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aad016a3.png",
    "team2": "غينيا بيساو",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52aad206e8.png",
    "time": "19:00",
    "score1": 1,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-8.html",
    "channel": "beIN Sports 8"
  },
  {
    "id": "m15",
    "team1": "أرمينيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52addd3216.png",
    "team2": "قبرص",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52adddc52a.png",
    "time": "20:00",
    "score1": 1,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-4.html",
    "channel": "beIN Sports 4"
  },
  {
    "id": "m16",
    "team1": "تركيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad9cca89.png",
    "team2": "بلجيكا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52ad9d5ee8.png",
    "time": "20:00",
    "score1": 1,
    "score2": 2,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "دوري الأمم الأوروبية",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-1.html",
    "channel": "beIN Sports 1"
  },
  {
    "id": "m17",
    "team1": "غينيا",
    "logo1": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52acf339ef.png",
    "team2": "إرتريا",
    "logo2": "https://hd-4kkora-live.live/wp-content/uploads/2026/11/alba_img_6af52acf42155.png",
    "time": "20:00",
    "score1": 2,
    "score2": 1,
    "status": "finished",
    "statusText": "انتهت",
    "tournament": "تصفيات كأس أمم أفريقيا",
    "streamUrl": "https://11.kooora4sport.fun/2026/09/bein-sport-7.html",
    "channel": "beIN Sports 7"
  }
];

class KooraUserApp extends StatefulWidget {
  const KooraUserApp({super.key});

  @override
  State<KooraUserApp> createState() => _KooraUserAppState();
}

class _KooraUserAppState extends State<KooraUserApp> {
  bool isNightMode = true;
  String selectedFilter = 'all';

  /// فتح المباراة مباشرة في تطبيق المشغل الخارجي (App 3) عبر Deep Link
  Future<void> _openInExternalPlayer(BuildContext context, Map<String, dynamic> match) async {
    final String encodedUrl = Uri.encodeComponent(match['streamUrl']);
    final String encodedTitle = Uri.encodeComponent('${match["team1"]} vs ${match["team2"]}');
    final String encodedChannel = Uri.encodeComponent(match['channel']);
    final Uri deepLink = Uri.parse(
      'kooraplayer://play?url=$encodedUrl&title=$encodedTitle&channel=$encodedChannel&id=${match["id"]}'
    );

    if (await canLaunchUrl(deepLink)) {
      await launchUrl(deepLink, mode: LaunchMode.externalApplication);
    } else {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('جاري تحويل البث إلى المشغل الخارجي: ${match["team1"]} ضد ${match["team2"]}'),
            backgroundColor: const Color(0xFF10B981),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final filteredMatches = initialMatches.where((m) {
      if (selectedFilter == 'all') return true;
      return m['status'] == selectedFilter;
    }).toList();

    return MaterialApp(
      title: 'كورة لايف - Koora Live',
      debugShowCheckedModeBanner: false,
      theme: isNightMode ? ThemeData.dark() : ThemeData.light(),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: isNightMode ? const Color(0xFF1C2733) : const Color(0xFFECEEF2),
          appBar: AppBar(
            backgroundColor: isNightMode ? const Color(0xFF263545) : Colors.white,
            title: const Row(
              children: [
                Icon(Icons.sports_soccer, color: Color(0xFF10B981)),
                SizedBox(width: 8),
                Text('كورة لايف - Koora Live', style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
            actions: [
              IconButton(
                icon: Icon(isNightMode ? Icons.wb_sunny : Icons.nightlight_round),
                onPressed: () => setState(() => isNightMode = !isNightMode),
              ),
            ],
          ),
          body: Column(
            children: [
              // شريط تبويبات جدول المباريات (بدون أي إعلانات بفضل StealthAdBlocker)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                color: isNightMode ? const Color(0xFF121A23) : Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _filterChip('الكل', 'all'),
                    _filterChip('جارية الان', 'live'),
                    _filterChip('بعد قليل', 'comming-soon'),
                    _filterChip('انتهت', 'finished'),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: filteredMatches.length,
                  itemBuilder: (context, index) {
                    final m = filteredMatches[index];
                    final isLive = m['status'] == 'live';
                    return GestureDetector(
                      onTap: () => _openInExternalPlayer(context, m),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: isNightMode ? const Color(0xFF263545) : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: isLive ? Border.all(color: Colors.redAccent, width: 1.2) : null,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  Text(m['team1'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15), textAlign: TextAlign.center),
                                ],
                              ),
                            ),
                            Column(
                              children: [
                                if (m['status'] == 'comming-soon')
                                  Text(m['time'], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))
                                else
                                  Text('${m["score1"]} - ${m["score2"]}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: isLive
                                        ? const Color(0xFFD00000)
                                        : (m['status'] == 'comming-soon' ? const Color(0xFF0F6F37) : const Color(0xFF474747)),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(m['statusText'], style: const TextStyle(color: Colors.white, fontSize: 12)),
                                ),
                                const SizedBox(height: 4),
                                Text(m['tournament'], style: const TextStyle(fontSize: 11, color: Colors.grey)),
                              ],
                            ),
                            Expanded(
                              child: Column(
                                children: [
                                  Text(m['team2'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15), textAlign: TextAlign.center),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _filterChip(String label, String value) {
    final active = selectedFilter == value;
    return ChoiceChip(
      label: Text(label),
      selected: active,
      onSelected: (_) => setState(() => selectedFilter = value),
    );
  }
}
