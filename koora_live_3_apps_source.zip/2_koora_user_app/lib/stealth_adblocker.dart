/// محرك حجب الإعلانات الخفي (Stealth Ad-Blocker Engine)
/// يعمل في الخلفية بصمت تام لحذف جميع الإعلانات والنوافذ المنبثقة من الموقع والسيرفرات
class StealthAdBlocker {
  /// قائمة النطاقات والروابط الإعلانية المحظورة تماماً على مستوى الشبكة
  static const List<String> blockedDomains = [
    'doubleclick.net',
    'googlesyndication.com',
    'googletagmanager.com',
    'google-analytics.com',
    'adservice.google.com',
    'koorascore.online',
    'com.modrajkora.app2026',
    'popads.net',
    'popcash.net',
    'propellerads.com',
    'adsterra.com',
    'exoclick.com',
  ];

  /// فحص ما إذا كان الرابط إعلانياً لمنعه في الخفاء قبل تحميله
  static bool shouldBlockUrl(String url) {
    final lower = url.toLowerCase();
    for (final domain in blockedDomains) {
      if (lower.contains(domain)) {
        return true;
      }
    }
    return false;
  }

  /// كود JavaScript الخفي الذي يتم حقنه تلقائياً لحذف عناصر الإعلانات من DOM
  static const String stealthDomInjectionScript = '''
    (function() {
      const adSelectors = [
        '.albayalla-e3lan',
        '.e3lan-before_table_content',
        '.e3lan-thumb_start',
        '.koora-match-ad',
        '[aria-label*="إعلان"]',
        'a[rel*="sponsored"]',
        'iframe[src*="ads"]',
        'iframe[src*="doubleclick"]'
      ];
      function cleanAdsSilently() {
        adSelectors.forEach(sel => {
          document.querySelectorAll(sel).forEach(el => el.remove());
        });
      }
      // منع النوافذ المنبثقة (Pop-ups) تماماً
      window.open = function() { return null; };
      cleanAdsSilently();
      const observer = new MutationObserver(cleanAdsSilently);
      observer.observe(document.documentElement, { childList: true, subtree: true });
    })();
  ''';
}
