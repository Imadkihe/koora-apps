#!/usr/bin/env bash
set -e
echo "Building All 3 Koora Live APKs..."

cd 1_koora_admin_app
flutter create . --project-name koora_admin_app --org com.kooralive.admin
flutter pub get
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk ../1_Koora_Admin.apk
cd ..

cd 2_koora_user_app
flutter create . --project-name koora_user_app --org com.kooralive.userapp
flutter pub get
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk ../2_Koora_User_Main.apk
cd ..

cd 3_koora_external_player_app
flutter create . --project-name koora_external_player_app --org com.kooralive.player
flutter pub get
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk ../3_Koora_External_Player.apk
cd ..

echo "All 3 APKs generated successfully!"
