@echo off
echo ===================================================
echo Building All 3 Koora Live APKs (Admin, User, Player)
echo ===================================================

cd 1_koora_admin_app
call flutter create . --project-name koora_admin_app --org com.kooralive.admin
call flutter pub get
call flutter build apk --release
copy build\app\outputs\flutter-apk\app-release.apk ..\1_Koora_Admin.apk
cd ..

cd 2_koora_user_app
call flutter create . --project-name koora_user_app --org com.kooralive.userapp
call flutter pub get
call flutter build apk --release
copy build\app\outputs\flutter-apk\app-release.apk ..\2_Koora_User_Main.apk
cd ..

cd 3_koora_external_player_app
call flutter create . --project-name koora_external_player_app --org com.kooralive.player
call flutter pub get
call flutter build apk --release
copy build\app\outputs\flutter-apk\app-release.apk ..\3_Koora_External_Player.apk
cd ..

echo Done! Your 3 APK files are ready in the main folder:
echo 1_Koora_Admin.apk
echo 2_Koora_User_Main.apk
echo 3_Koora_External_Player.apk
pause
